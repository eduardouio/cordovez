<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Ordena la lista de pedidos y averigua si tiene o no demoraje
 *
 * @package CordovezApp
 * @author Eduardo Villota <eduardouio7@gmail.com>
 * @copyright Copyright (c) 2014, Agencias y Representaciones Cordovez S.A.
 * @license Derechos reservados Agencias y Representaciones Cordovez S.A.
 * @link https://github.com/eduardouio/APPImportaciones
 * @since Version 1.0.0
 * @filesource
 */
class OrderList
{
    
}

