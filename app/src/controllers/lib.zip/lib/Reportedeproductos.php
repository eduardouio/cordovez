<?php
namespace src\controllers\lib;

class Reportedeproductos
{
}

